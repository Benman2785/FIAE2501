package com.example.xmlklausurasmus;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TwitterActivity extends AppCompatActivity implements View.OnClickListener {

    EditText inputUsername, inputPassword;
    Button anmeldeBTN;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twitter);

        // Objekte mit XML verknüpfen
        inputUsername = findViewById(R.id.editTextPw3);
        inputPassword = findViewById(R.id.editTextUsername3);
        anmeldeBTN = findViewById(R.id.buttonTw3);
        anmeldeBTN.setOnClickListener(this);

        // Werte herausholen (Siehe Mainactivity Zeile 71 und 72)
        if(getIntent() != null) {
            String username = getIntent().getStringExtra("username");
            String pw = getIntent().getStringExtra("pw");

            Log.i("XXX", username);
            Log.i("XXX", pw);
        }
    }
    @Override
    public void onClick(View view) {

    }



}