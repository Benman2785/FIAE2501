package com.example.xmlklausurasmus;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

/**
 * huhu
 */
public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*
        mehr
        zeilig
         */

        // Layout festlegen
        setContentView(R.layout.activity_main);
    }

    
}